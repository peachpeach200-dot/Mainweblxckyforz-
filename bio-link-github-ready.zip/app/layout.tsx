import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bio Link",
  description: "A Supabase-powered bio link page with an admin dashboard."
};

export default function RootLayout({
  children
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="th">
      <body>{children}</body>
    </html>
  );
}
