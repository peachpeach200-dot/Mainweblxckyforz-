import PublicProfile from "@/components/PublicProfile";

export const dynamic = "force-dynamic";

export default function Home() {
  return <PublicProfile />;
}
