export type Profile = {
  $id: string;
  $createdAt?: string;
  $updatedAt?: string;
  display_name: string;
  bio: string;
  avatar_url: string | null;
  cover_url: string | null;
  avatar_effect: "none" | "glow" | "neon" | "spin" | "shadow";
  font_family: "Inter" | "Poppins" | "Prompt" | "Kanit" | "Mitr" | "system";
};

export type BioLink = {
  $id: string;
  $createdAt?: string;
  $updatedAt?: string;
  title: string;
  url: string;
  icon_url: string | null;
  position_order: number;
  is_active: boolean;
};
