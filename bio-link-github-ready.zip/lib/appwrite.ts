import { Account, Client, Databases, ID, Permission, Query, Role, Storage } from "appwrite";

const endpoint = process.env.NEXT_PUBLIC_APPWRITE_ENDPOINT;
const projectId = process.env.NEXT_PUBLIC_APPWRITE_PROJECT_ID;

if (!endpoint || !projectId) {
  throw new Error("Missing Appwrite endpoint/project ID. Copy .env.example to .env.local.");
}

export const client = new Client().setEndpoint(endpoint).setProject(projectId);
export const account = new Account(client);
export const databases = new Databases(client);
export const storage = new Storage(client);

export const APPWRITE_DATABASE_ID = process.env.NEXT_PUBLIC_APPWRITE_DATABASE_ID!;
export const PROFILE_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_PROFILE_COLLECTION_ID!;
export const LINKS_COLLECTION_ID = process.env.NEXT_PUBLIC_APPWRITE_LINKS_COLLECTION_ID!;
export const BUCKET_ID = process.env.NEXT_PUBLIC_APPWRITE_BUCKET_ID!;
export const ADMIN_USER_ID = process.env.NEXT_PUBLIC_APPWRITE_ADMIN_USER_ID!;
export const ADMIN_TEAM_ID = process.env.NEXT_PUBLIC_APPWRITE_ADMIN_TEAM_ID || "";

export { ID, Permission, Query, Role };
