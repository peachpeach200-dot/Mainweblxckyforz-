"use client";

import { useEffect, useMemo, useState } from "react";
import { client, databases, APPWRITE_DATABASE_ID, PROFILE_COLLECTION_ID, LINKS_COLLECTION_ID, Query } from "@/lib/appwrite";
import type { BioLink, Profile } from "@/lib/types";
import { ExternalLink } from "lucide-react";

const fallbackProfile: Profile = {
  $id: "profile",
  display_name: "Your Name",
  bio: "Your bio goes here.",
  avatar_url: null,
  cover_url: null,
  avatar_effect: "glow",
  font_family: "Inter"
};

const fontMap: Record<Profile["font_family"], string> = {
  Inter: 'Inter, "Segoe UI", sans-serif',
  Poppins: 'Poppins, "Segoe UI", sans-serif',
  Prompt: 'Prompt, "Segoe UI", sans-serif',
  Kanit: 'Kanit, "Segoe UI", sans-serif',
  Mitr: 'Mitr, "Segoe UI", sans-serif',
  system: 'system-ui, sans-serif'
};

export default function PublicProfile() {
  const [profile, setProfile] = useState<Profile>(fallbackProfile);
  const [links, setLinks] = useState<BioLink[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const [p, l] = await Promise.all([
        databases.getDocument<Profile>(APPWRITE_DATABASE_ID, PROFILE_COLLECTION_ID, "profile"),
        databases.listDocuments<BioLink>(APPWRITE_DATABASE_ID, LINKS_COLLECTION_ID, [
          Query.equal("is_active", true),
          Query.orderAsc("position_order"),
          Query.limit(100)
        ])
      ]);
      setProfile(p);
      setLinks(l.documents);
    } catch {
      // Keep the fallback UI when Appwrite is not configured or no profile exists yet.
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const unsubscribe = client.subscribe([
      `databases.${APPWRITE_DATABASE_ID}.collections.${PROFILE_COLLECTION_ID}.documents`,
      `databases.${APPWRITE_DATABASE_ID}.collections.${LINKS_COLLECTION_ID}.documents`
    ], () => load());
    return () => unsubscribe();
  }, []);

  const font = useMemo(() => fontMap[profile.font_family] ?? fontMap.Inter, [profile.font_family]);

  if (loading) {
    return <main className="public-page"><div className="public-shell"><div className="card" style={{ padding: 24 }}>กำลังโหลด…</div></div></main>;
  }

  return (
    <main className="public-page" style={{ fontFamily: font }}>
      <div className="public-shell">
        <div className="cover" style={profile.cover_url ? { backgroundImage: `url("${profile.cover_url}")` } : undefined} />
        <section className="profile-head">
          <img className={`avatar effect-${profile.avatar_effect}`} src={profile.avatar_url ?? "/avatar-placeholder.svg"} alt={profile.display_name} />
          <h1 className="profile-name">{profile.display_name}</h1>
          <div className="profile-bio">{profile.bio}</div>
        </section>
        <div className="links">
          {links.map(link => (
            <a key={link.$id} className="public-link" href={link.url} target="_blank" rel="noreferrer noopener">
              {link.icon_url ? <img className="link-thumb" src={link.icon_url} alt="" /> : <span className="link-thumb" style={{ display: "grid", placeItems: "center" }}><ExternalLink size={20} /></span>}
              <span className="link-title">{link.title}</span>
              <span className="link-arrow">↗</span>
            </a>
          ))}
          {!links.length && <div className="card" style={{ padding: 20, textAlign: "center" }}>ยังไม่มีลิงก์ที่เปิดใช้งาน</div>}
        </div>
      </div>
    </main>
  );
}
