"use client";

import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { account, ADMIN_USER_ID } from "@/lib/appwrite";

export default function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    account.get().then(user => {
      if (!ADMIN_USER_ID || user.$id === ADMIN_USER_ID) router.replace("/admin");
    }).catch(() => {});
  }, [router]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const user = await account.createEmailPasswordSession(email, password);
      if (ADMIN_USER_ID && user.userId !== ADMIN_USER_ID) {
        await account.deleteSession("current");
        throw new Error("บัญชีนี้ไม่มีสิทธิ์ Admin");
      }
      router.replace("/admin");
    } catch (e) {
      setError(e instanceof Error ? e.message : "เข้าสู่ระบบไม่สำเร็จ");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="page-center">
      <form className="card panel" style={{ width: "min(420px,100%)" }} onSubmit={submit}>
        <h1 style={{ marginTop: 0 }}>Admin Login</h1>
        <p className="muted">เข้าสู่ระบบเพื่อแก้ไข Bio Link</p>
        <div className="stack">
          <div className="field"><label>Email</label><input type="email" required value={email} onChange={e => setEmail(e.target.value)} /></div>
          <div className="field"><label>Password</label><input type="password" required value={password} onChange={e => setPassword(e.target.value)} /></div>
          {error && <div className="error">{error}</div>}
          <button className="btn primary" disabled={loading}>{loading ? "กำลังเข้าสู่ระบบ…" : "เข้าสู่ระบบ"}</button>
        </div>
      </form>
    </main>
  );
}
