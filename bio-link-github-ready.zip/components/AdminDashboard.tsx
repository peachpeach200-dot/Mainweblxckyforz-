"use client";

import { DndContext, DragEndEvent, PointerSensor, closestCenter, useSensor, useSensors } from "@dnd-kit/core";
import { SortableContext, arrayMove, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { LogOut, GripVertical, Plus, Trash2, Upload, ExternalLink } from "lucide-react";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  account, databases, storage, client, ID, Permission, Role,
  APPWRITE_DATABASE_ID, PROFILE_COLLECTION_ID, LINKS_COLLECTION_ID,
  BUCKET_ID, ADMIN_USER_ID, ADMIN_TEAM_ID, Query
} from "@/lib/appwrite";
import type { BioLink, Profile } from "@/lib/types";

const DEFAULT_PROFILE: Omit<Profile, "$id" | "$createdAt" | "$updatedAt"> = {
  display_name: "Your Name",
  bio: "Write something about yourself.",
  avatar_url: null,
  cover_url: null,
  avatar_effect: "glow",
  font_family: "Inter"
};

const effects: Profile["avatar_effect"][] = ["none", "glow", "neon", "spin", "shadow"];
const fonts: Profile["font_family"][] = ["Inter", "Poppins", "Prompt", "Kanit", "Mitr", "system"];

function adminWritePermissions() {
  const role = ADMIN_TEAM_ID ? Role.team(ADMIN_TEAM_ID) : Role.user(ADMIN_USER_ID);
  return [Permission.read(Role.any()), Permission.update(role), Permission.delete(role)];
}

async function uploadAsset(file: File, folder: "avatars" | "covers" | "icons") {
  if (!file.type.startsWith("image/")) throw new Error("ไฟล์ต้องเป็นรูปภาพ");
  const fileId = ID.unique();
  await storage.createFile({
    bucketId: BUCKET_ID,
    fileId,
    file,
    permissions: [Permission.read(Role.any()), ...adminWritePermissions().filter(p => !p.startsWith("read("))]
  });
  return storage.getFileView({ bucketId: BUCKET_ID, fileId }).toString();
}

function SortableLink({ link, onChange, onDelete, onUpload }: {
  link: BioLink;
  onChange: (patch: Partial<BioLink>) => void;
  onDelete: () => void;
  onUpload: (file: File) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: link.$id });
  const style = { transform: CSS.Transform.toString(transform), transition };
  return (
    <div ref={setNodeRef} style={style} className="link-editor">
      <button className="btn drag-handle" type="button" {...attributes} {...listeners} title="ลากเพื่อจัดลำดับ"><GripVertical size={17} /></button>
      {link.icon_url ? <img className="small-thumb" src={link.icon_url} alt="" /> : <div className="small-thumb" style={{ display: "grid", placeItems: "center" }}><ExternalLink size={18} /></div>}
      <div className="stack" style={{ gap: 8 }}>
        <input value={link.title} placeholder="ชื่อปุ่ม" onChange={e => onChange({ title: e.target.value })} />
        <input value={link.url} placeholder="https://example.com" onChange={e => onChange({ url: e.target.value })} />
        <div className="row">
          <label className="btn" style={{ padding: "7px 10px" }}>
            <Upload size={15} style={{ verticalAlign: "middle" }} /> ไอคอน
            <input hidden type="file" accept="image/*" onChange={e => e.target.files?.[0] && onUpload(e.target.files[0])} />
          </label>
          <label className="switch"><input type="checkbox" checked={link.is_active} onChange={e => onChange({ is_active: e.target.checked })} />แสดงบนหน้าเว็บ</label>
        </div>
      </div>
      <div className="link-actions row"><button className="btn danger" type="button" onClick={onDelete}><Trash2 size={16} /></button></div>
    </div>
  );
}

export default function AdminDashboard() {
  const router = useRouter();
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));
  const [profile, setProfile] = useState<Profile | null>(null);
  const [links, setLinks] = useState<BioLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    async function boot() {
      try {
        const user = await account.get();
        if (ADMIN_USER_ID && user.$id !== ADMIN_USER_ID) throw new Error("บัญชีนี้ไม่มีสิทธิ์ Admin");

        let p: Profile;
        try {
          p = await databases.getDocument<Profile>(APPWRITE_DATABASE_ID, PROFILE_COLLECTION_ID, "profile");
        } catch {
          p = await databases.createDocument<Profile>(
            APPWRITE_DATABASE_ID, PROFILE_COLLECTION_ID, "profile", DEFAULT_PROFILE, adminWritePermissions()
          );
        }
        const l = await databases.listDocuments<BioLink>(APPWRITE_DATABASE_ID, LINKS_COLLECTION_ID, [Query.orderAsc("position_order"), Query.limit(100)]);
        setProfile(p);
        setLinks(l.documents);
      } catch (e) {
        const msg = e instanceof Error ? e.message : "โหลดข้อมูลไม่ได้";
        if (msg.toLowerCase().includes("unauthorized") || msg.toLowerCase().includes("not authorized") || msg.includes("ไม่ได้เข้าสู่ระบบ")) router.replace("/login");
        else setError(msg);
      } finally {
        setLoading(false);
      }
    }
    boot();
  }, [router]);

  function patchLink(id: string, patch: Partial<BioLink>) {
    setLinks(prev => prev.map(x => x.$id === id ? { ...x, ...patch } : x));
  }

  async function onAvatar(file: File) {
    try { const url = await uploadAsset(file, "avatars"); setProfile(p => p ? { ...p, avatar_url: url } : p); }
    catch (e) { setError(e instanceof Error ? e.message : "อัปโหลดไม่สำเร็จ"); }
  }
  async function onCover(file: File) {
    try { const url = await uploadAsset(file, "covers"); setProfile(p => p ? { ...p, cover_url: url } : p); }
    catch (e) { setError(e instanceof Error ? e.message : "อัปโหลดไม่สำเร็จ"); }
  }
  async function onLinkIcon(id: string, file: File) {
    try { const url = await uploadAsset(file, "icons"); patchLink(id, { icon_url: url }); }
    catch (e) { setError(e instanceof Error ? e.message : "อัปโหลดไม่สำเร็จ"); }
  }

  function addLink() {
    setLinks(prev => [...prev, { $id: `local-${crypto.randomUUID()}`, title: "New Link", url: "https://", icon_url: null, position_order: prev.length, is_active: true }]);
  }

  function removeLink(id: string) {
    if (!confirm("ลบลิงก์นี้ใช่ไหม?")) return;
    setLinks(prev => prev.filter(x => x.$id !== id));
  }

  function onDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    setLinks(prev => {
      const oldIndex = prev.findIndex(x => x.$id === active.id);
      const newIndex = prev.findIndex(x => x.$id === over.id);
      return arrayMove(prev, oldIndex, newIndex).map((x, i) => ({ ...x, position_order: i }));
    });
  }

  async function save() {
    if (!profile) return;
    setSaving(true); setError(""); setMessage("");
    try {
      await databases.updateDocument<Profile>(APPWRITE_DATABASE_ID, PROFILE_COLLECTION_ID, profile.$id, {
        display_name: profile.display_name, bio: profile.bio, avatar_url: profile.avatar_url,
        cover_url: profile.cover_url, avatar_effect: profile.avatar_effect, font_family: profile.font_family
      });

      const saved: BioLink[] = [];
      for (const x of links) {
        const data = { title: x.title, url: x.url, icon_url: x.icon_url, position_order: saved.length, is_active: x.is_active };
        const doc = x.$id.startsWith("local-")
          ? await databases.createDocument<BioLink>(APPWRITE_DATABASE_ID, LINKS_COLLECTION_ID, ID.unique(), data, adminWritePermissions())
          : await databases.updateDocument<BioLink>(APPWRITE_DATABASE_ID, LINKS_COLLECTION_ID, x.$id, data);
        saved.push(doc);
      }

      const dbRows = await databases.listDocuments<BioLink>(APPWRITE_DATABASE_ID, LINKS_COLLECTION_ID, [Query.limit(100)]);
      const keep = new Set(saved.map(x => x.$id));
      for (const row of dbRows.documents) if (!keep.has(row.$id)) await databases.deleteDocument(APPWRITE_DATABASE_ID, LINKS_COLLECTION_ID, row.$id);

      setLinks(saved);
      setMessage("บันทึกเรียบร้อย — หน้า Public จะอัปเดตตามข้อมูลล่าสุด");
    } catch (e) {
      setError(e instanceof Error ? e.message : "บันทึกไม่สำเร็จ");
    } finally { setSaving(false); }
  }

  async function logout() {
    try { await account.deleteSession("current"); } finally { router.replace("/login"); }
  }

  if (loading) return <main className="page-center"><div className="card panel">กำลังโหลด Admin…</div></main>;
  if (!profile) return <main className="page-center"><div className="card panel error">{error || "โหลดข้อมูลไม่ได้"}</div></main>;

  return (
    <main className="admin-page">
      <div className="container">
        <header className="admin-header">
          <div><h1>Bio Link Admin</h1><div className="muted">จัดการโปรไฟล์และลิงก์ของคุณ</div></div>
          <div className="row"><a className="btn" href="/" target="_blank" rel="noreferrer">ดูหน้าเว็บ</a><button className="btn" onClick={logout}><LogOut size={16} /> ออกจากระบบ</button></div>
        </header>
        {error && <div className="error" style={{ marginBottom: 16 }}>{error}</div>}
        {message && <div className="notice" style={{ marginBottom: 16 }}>{message}</div>}
        <div className="grid two">
          <section className="card panel">
            <h2>โปรไฟล์</h2>
            <div className="stack">
              <div className="field"><label>ชื่อที่แสดง</label><input value={profile.display_name} onChange={e => setProfile({ ...profile, display_name: e.target.value })} /></div>
              <div className="field"><label>Bio</label><textarea value={profile.bio} onChange={e => setProfile({ ...profile, bio: e.target.value })} /></div>
              <div className="field"><label>Avatar</label><div className="row">{profile.avatar_url && <img className="preview-img" src={profile.avatar_url} alt="" />}<label className="btn"><Upload size={16} /> เลือกรูป/GIF<input hidden type="file" accept="image/*,.gif" onChange={e => e.target.files?.[0] && onAvatar(e.target.files[0])} /></label></div></div>
              <div className="field"><label>Cover Image</label>{profile.cover_url && <img className="cover-preview" src={profile.cover_url} alt="" />}<label className="btn"><Upload size={16} /> เลือกภาพปก<input hidden type="file" accept="image/*" onChange={e => e.target.files?.[0] && onCover(e.target.files[0])} /></label></div>
              <div className="field"><label>Avatar Effect</label><select value={profile.avatar_effect} onChange={e => setProfile({ ...profile, avatar_effect: e.target.value as Profile["avatar_effect"] })}>{effects.map(x => <option key={x} value={x}>{x}</option>)}</select></div>
              <div className="field"><label>Font Family</label><select value={profile.font_family} onChange={e => setProfile({ ...profile, font_family: e.target.value as Profile["font_family"] })}>{fonts.map(x => <option key={x} value={x}>{x}</option>)}</select></div>
            </div>
          </section>
          <section className="card panel">
            <div className="row" style={{ justifyContent: "space-between" }}><div><h2 style={{ marginBottom: 4 }}>Links</h2><div className="muted">ลากเพื่อเปลี่ยนลำดับ</div></div><button className="btn" onClick={addLink}><Plus size={16} /> เพิ่มลิงก์</button></div>
            <div style={{ marginTop: 14 }}><DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}><SortableContext items={links.map(x => x.$id)} strategy={verticalListSortingStrategy}><div className="stack">{links.map(link => <SortableLink key={link.$id} link={link} onChange={patch => patchLink(link.$id, patch)} onDelete={() => removeLink(link.$id)} onUpload={file => onLinkIcon(link.$id, file)} />)}</div></SortableContext></DndContext></div>
          </section>
        </div>
        <div className="actions"><button className="btn primary" onClick={save} disabled={saving}>{saving ? "กำลังบันทึก…" : "บันทึกทุกอย่าง"}</button></div>
      </div>
    </main>
  );
}
